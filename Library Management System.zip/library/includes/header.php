
    <!-- LOGO HEADER END-->

<section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <?php if($_SESSION['login'])
{
                            ?> 
                        <ul id="menu-top" class="nav navbar-nav navbar-left">
                            
                             <li><a href="logout.php" class="" style="text-align: left;">Logout</a></li>
                        </ul>

                             <?php }?>
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                           
                            <?php if($_SESSION['login'])
                            {
                            ?>    
                            <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
                           
                          
                            <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Account <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="my-profile.php">My Profile</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="change-password.php">Change Password</a></li>
                                </ul>
                            </li>
                            <li><a href="issued-books.php">Issued Books</a></li>
                          

                            <?php } else { ?>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="userlogin.php">User Login</a></li>

                            <?php } ?>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>

      